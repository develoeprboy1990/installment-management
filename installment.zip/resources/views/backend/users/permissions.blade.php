@extends('layouts.master')
@push('styles')
    <style>
        .permission-actions {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
            margin-bottom: 15px;
            flex-wrap: wrap;
        }

        .permission-actions .actions {
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .permission-actions .btn-link {
            padding: 0;
            font-weight: 600;
        }

        .permission-actions .divider {
            color: #c2c2c2;
        }
    </style>
@endpush
@section('content')
    @php
        $breadcrumbs = [['title' => 'Permissions', 'url' => route('permissions'), 'active' => false]];
        $pageTitle = 'Permissions';
        $buttons = [
            [
                'title' => 'Add Permission',
                'modal' => '#addPermission',
                'class' => 'btn-primary',
                'icon' => 'bi bi-plus-circle',
            ],
        ];
    @endphp
    @include('backend.partials.breadcrumb', [
        'pageTitle' => $pageTitle,
        'breadcrumbs' => $breadcrumbs,
        'buttons' => $buttons,
    ])
    {{-- <section class="section">
        <div class="card">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Role Name</th>
                    <th>Permissions</th>
                </tr>
            </thead>
            <tbody>
                @foreach($roles as $role)
                    <tr>
                        <td>{{ $role->name }}</td>
                        <td>
                            <form action="{{ route('permissions.update', $role->id) }}" method="POST">
                                @csrf
                                @method('PUT')
                                @foreach($permissions as $permission)
                                    <div class="form-check">
                                        <input
                                            type="checkbox"
                                            class="form-check-input"
                                            id="permission-{{ $role->id }}-{{ $permission->id }}"
                                            name="permissions[]"
                                            value="{{ $permission->id }}"
                                            {{ $role->permissions->contains($permission) ? 'checked' : '' }}
                                        >
                                        <label
                                            class="form-check-label"
                                            for="permission-{{ $role->id }}-{{ $permission->id }}"
                                        >
                                            {{ $permission->name }}
                                        </label>
                                    </div>
                                @endforeach
                                <button type="submit" class="btn btn-primary mt-2">Update Permissions</button>
                            </form>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
        </div>

    </section> --}}

    <div class="wrapper wrapper-content animated fadeInRight">
        <div class="row">
            <div class="col-lg-12">
                <div class="ibox float-e-margins">
                    <div class="ibox-content">
                        <div class="table-responsive">
                            <table id="table1" class="table table-striped table-bordered table-hover dataTables-example" >
                                <thead>
                                    <tr>
                                        <th width="20%">Role Name</th>
                                        <th width="80%">Permissions</th>
                                    </tr>
                                </thead>
                                <tbody>

                                    @foreach($roles as $role)
                                        <tr>
                                            <td>{{ $role->name }}</td>
                                            <td>
                                                <form action="{{ route('permissions.update', $role->id) }}" method="POST"
                                                    class="permission-form">
                                                    @csrf
                                                    @method('PUT')
                                                    <div class="permission-actions">
                                                        <strong class="text-muted">Assign permissions</strong>
                                                        <div class="actions">
                                                            <button type="button" class="btn btn-link btn-sm permission-toggle"
                                                                data-target="permission-list-{{ $role->id }}"
                                                                data-action="select">
                                                                <i class="fa fa-check-square-o"></i> Select All
                                                            </button>
                                                            <span class="divider">|</span>
                                                            <button type="button" class="btn btn-link btn-sm permission-toggle"
                                                                data-target="permission-list-{{ $role->id }}"
                                                                data-action="clear">
                                                                <i class="fa fa-square-o"></i> Clear
                                                            </button>
                                                        </div>
                                                    </div>
                                                    <div class="row permission-list" id="permission-list-{{ $role->id }}">
                                                        @foreach ($permissions as $permission)
                                                            <div class="col-md-4 col-sm-6 mb-2">
                                                                <div class="form-check">
                                                                    <input type="checkbox" class="form-check-input"
                                                                        id="permission-{{ $role->id }}-{{ $permission->id }}"
                                                                        name="permissions[]" value="{{ $permission->id }}"
                                                                        {{ $role->permissions->contains($permission) ? 'checked' : '' }}>
                                                                    <label class="form-check-label"
                                                                        for="permission-{{ $role->id }}-{{ $permission->id }}">
                                                                        {{ $permission->name }}
                                                                    </label>
                                                                </div>
                                                            </div>
                                                        @endforeach
                                                    </div>
                                                    <button type="submit" class="btn btn-primary mt-3">Update
                                                        Permissions</button>
                                                </form>
                                            </td>
                                        </tr>
                                    @endforeach

                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    {{-- <div class="modal fade text-left" id="addPermission" tabindex="-1" role="dialog"
        aria-labelledby="myModalLabel33" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable"
            role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="myModalLabel33">Add Permission</h4>
                    <button type="button" class="close" data-bs-dismiss="modal"
                        aria-label="Close">
                        <i data-feather="x"></i>
                    </button>
                </div>
                <form action="{{ route('permissions.store') }}" method="POST">
                    @csrf
                    <div class="modal-body">
                        <label for="name">Permission: </label>
                        <div class="form-group">
                            <input id="name" type="text" name="name" placeholder="add permission"
                                class="form-control" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-light-secondary"
                            data-bs-dismiss="modal">
                            <i class="bx bx-x d-block d-sm-none"></i>
                            <span class="d-none d-sm-block">Close</span>
                        </button>
                        <button type="submit" class="btn btn-primary ms-1"
                            data-bs-dismiss="modal">
                            <i class="bx bx-check d-block d-sm-none"></i>
                            <span class="d-none d-sm-block">Add</span>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div> --}}

    <div class="modal inmodal" id="addPermission" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable">
            <div class="modal-content animated fadeIn">
                <div class="modal-header">
                    <h4 class="modal-title" id="myModalLabel33">Add Permission</h4>
                </div>
                <form action="{{ route('permissions.store') }}" method="POST">
                    @csrf
                    <div class="modal-body">
                        <label for="name">Permission: </label>
                        <div class="form-group">
                            <input id="name" type="text" name="name" placeholder="Add permission"
                                class="form-control" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-white" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Add</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection

@push('script')
    <script>
        $(document).ready(function() {
            $('.permission-form').on('click', '.permission-toggle', function(e) {
                e.preventDefault();

                const action = $(this).data('action');
                const targetId = $(this).data('target');
                const $targetList = $('#' + targetId);

                if (!$targetList.length) {
                    console.warn('Permission list not found for target:', targetId);
                    return;
                }

                const shouldSelect = action === 'select';
                $targetList.find('input[type="checkbox"]').prop('checked', shouldSelect);

                // Provide quick visual confirmation
                const message = shouldSelect ? 'All permissions selected.' : 'All permissions cleared.';
                toastr.info(message);
            });
        });
    </script>
@endpush
